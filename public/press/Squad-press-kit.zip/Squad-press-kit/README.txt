Squad – press kit
Squad turns group chats into real plans: create a drop, your crew answers IN / LATE / OUT, everyone shows up.
Developer: Cube Mobile Games · cubemobilegame@gmail.com · https://squad-64cd5.web.app
Files: icon-1024.png · screens-*.jpg (app screenshots, panoramas 2580x2796 and 1290x2796) · sos-card-*.png (1920x1080, 3840x2160, 1080x1920)
